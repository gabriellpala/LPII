package Model;

public class  Enfermeiro {
    private String nome;
    private String coren;

    public Enfermeiro(String nome, String coren) {
        this.nome = nome;
        this.coren = coren;
    }

    public String getNome() {
        return nome;
    }

    public String getCoren() {
        return coren;
    }
}


    
